"""Version information for RAE-core."""

__version__ = "0.4.2"
__author__ = "Grzegorz Leśniowski"
__email__ = "contact@dreamsoft.pro"
__license__ = "Apache-2.0"

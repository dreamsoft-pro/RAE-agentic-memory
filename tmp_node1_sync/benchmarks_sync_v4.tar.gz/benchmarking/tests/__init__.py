"""
Benchmark tests package
"""

"""SQLite adapter tests."""
